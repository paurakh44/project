<?php


//Impoetant functions
echo "Hello";