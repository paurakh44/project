<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Bootstrap demo</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
  </head>
  <body>
    <div class="container">
    <table class="table">
        <pre>
            {{print_r($customers)}}
</pre>
  <thead>
    <tr>
      <th></th>
      <th ></th>
      <th ></th>
      <th ></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>Name</th>
      <th>Email</th>
      <th>Gender</th>
      <th>Dob</th>
      <th>State</th>
      <th>Country</th>
      <th>Status</th>
</tr>
</thead>
</tbody>
@foreach ($customers as $customers)
    </tr>
    <td>{{$customer->name}}</td>
    <td>{{$customer->email}}</td>
    <td>{{$customer->gender}}</td>
    <td>{{$customer->dob}}</td>
    <td>{{$customer->state}}</td>
    <td>{{$customer->country}}</td>
    <td>{{$customer->status}}</td>
</tr>
@endforeach
<td>
    <a href="{{url ('/customer/delete/')}}/{{$customer->customer_id}}"> <button class = "btn btn-danger ">Delete</button>
</a> 
<button class = "btn btn-primary ">Edit</button>
  </tbody>
</table>
    </div>
  </body>
</html>