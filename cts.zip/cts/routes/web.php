<?php
use App\Http\Controllers\Customercontroller;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\RegistrationController;
use App\Models\Customers;
use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/register',[Registrationcontroller::class,'index']);
Route::post('/register',[Registrationcontroller::class,'register']);
Route::get ('/customer/create',[CustomerController::class,'create']);
Route::get('/customer/delete/(id)',[customercontroller::class,'delete']);
Route::get ('/customer/view',[CustomerController::class,'view']);
Route::post ('/customer',[CustomerController::class,'store']);


Route::get('get-all-session',function(){
    $session=session()->all();
    p($session);
});

Route::get('set-session', function (Request $request){
    $request->session()->put('user_name','WsCube Tech');
    $request->session()->put('user_id','123');
    $request->session()->flash('status','success');
    return redirect('get-all-session');
});

Route::get('destroy-session',function(){
    session()->forget(['user_name','user_id']);
    //session()->forget('user_id');
    return redirect('get-all-session');
});