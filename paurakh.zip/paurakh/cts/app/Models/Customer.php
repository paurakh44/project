<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Customer extends Model
{
    use HasFactory;
    protected $table = "customers";
    protected $primarykey = "customer-id";

    public function setNameAtrribute($value)
    {
        $this->attributes['name']= ucwords($value);
    }
    public function getdobattribute($value)
    {
        return date("d-m-y",strtotime($value));
    }

}
