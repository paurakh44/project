<h1>Upload File</h1>
<form action="" method="Post" enctype="multipart/form-data">
  <?php echo csrf_field(); ?> 
  <input type="file" name="file"> <br> <br>
  <button type="submit" >Upload File</button>
</form><?php /**PATH C:\xampp\htdocs\upload file\kc\resources\views/upload.blade.php ENDPATH**/ ?>